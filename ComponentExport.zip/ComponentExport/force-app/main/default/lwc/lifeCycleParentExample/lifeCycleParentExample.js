import { LightningElement } from 'lwc';

export default class LifeCycleParentExample extends LightningElement {
    constructor(){
        super() //when we call a constructor method , we always need to call super method, its in the initilazition 
        //phase
        console.log("parent constructor called")
    }

    connectedCallback(){
        console.log("parent connectedCallback called")
    }

    renderedCallback(){
        console.log("parent renderedCallback called")
    }
    
    name
    changeHandler(event){
        this.name = this.event.value

    }
}