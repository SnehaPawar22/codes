import { LightningElement } from 'lwc';

export default class Modal extends LightningElement {}