import { LightningElement, wire } from 'lwc';
import createNoteRecord from '@salesforce/apex/NoteTakingController.createNoteRecord'
import getNotes from '@salesforce/apex/NoteTakingController.getNotes'

const DEFAULT_NOTE_FORM = {
    Name:"",
    Note_Description__c:""
  }

export default class NoteTakingApp extends LightningElement {
    showModal = false
    noteRecord = DEFAULT_NOTE_FORM
    noteList = []
    formats = [
        'font',
        'size',
        'bold',
        'italic',
        'underline',
        'strike',
        'list',
        'indent',
        'align',
        'link',
        'clean',
        'table',
        'header',
        'color',
    ];

    get formIsInvalid(){
        return !(this.noteRecord && this.noteRecord.Note_Description__c && this.noteRecord.Name)
        //disabling the save button on the component form
    }

    // @wire(getNotes)
    // noteListInfo({data,error}){
    //   if(data){
    //     console.log("data of notes",JSON.stringify(data))
    //     //whenever we want to transform a data we use "MAP"
    //     this.noteList = data.map(item=>{
    //       let formatDate = new Date(item, LastModifiedDate).toDateString() //date was showing in different formate
    //       //so used toDateString() method
    //       return {...item, formatDate}
    //     })
    //   }
    //   if(error){
    //       console.error("error while fetching",error)
    //       this.showToastMsg(error.message.body,'error')
    //   }
    // }//from @wire we are accessing the apex code logic from apex class
    //

    @wire(getNotes)
    noteListInfo({data, error}){
      if(data){
        console.log("data of notes", JSON.stringify(data))
        this.noteList = data.map(item=>{
          let formatDate = new Date(item.LastModifiedDate).toDateString()
          return {...item, formatDate}
        })
      }
      if(error){
        console.error("error in fetching", error)
        this.showToastMsg(error.message.body, 'error')
      }
    }



    createNoteHandler(){
        this.showModal = true
    }

    closeModalHandler(){
        this.showModal = false //hiding the modal
        this.noteRecord = DEFAULT_NOTE_FORM //empty the note record
    }

    changeHandler(event){
        const {name, value} = event.target
        // const name = event.target.name
        // const value = event.target.value
        // console.log(name)
        // console.log(value)
        this.noteRecord={...this.noteRecord, [name]:value}
        //whatever user is typing we are storing in the noteRecord
        
      }

      formSubmitHandler(event){
        event.preventDefault()
        console.log("note record values", JSON.stringify(this.noteRecord))
        this.createNote()
      }
   
      createNote(){
        createNoteRecord({title:this.noteRecord.Name, description:this.noteRecord.Note_Description__c}).then(()=>{
            this.showModal = false;
            this.showToastMsg("Note created successfully!!!!!!",'success')
        }).catch(error =>{
            console.error("error",error.message.body)
            this.showToastMsg(error.message.body,'error')
        })
      }

      showToastMsg(message,variant){
        const elem = this.template.querySelector('c-notification')
        if(elem){
            elem.showToast(message,variant)
        }
      }
    
}