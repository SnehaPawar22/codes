import { LightningElement } from 'lwc';

export default class HelloChildComponent extends LightningElement {}