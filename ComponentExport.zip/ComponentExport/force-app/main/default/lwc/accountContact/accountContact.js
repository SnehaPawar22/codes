import { LightningElement, track } from 'lwc';

export default class DisplayAccountContactDetails extends LightningElement {
    @track accountName = '';
    @track contactFirstName = '';
    @track contactLastName = '';
    @track contactEmail = '';
    @track displayDetails = false;
    @track accountId = '';
    @track contactId = '';

    handleAccountChange(event) {
        this.accountName = event.target.value;
    }

    handleContactFirstNameChange(event) {
        this.contactFirstName = event.target.value;
    }

    handleContactLastNameChange(event) {
        this.contactLastName = event.target.value;
    }

    handleContactEmailChange(event) {
        this.contactEmail = event.target.value;
    }

    handleSubmit() {
        // Perform submission logic here, like creating records in Salesforce
        // For demonstration purposes, let's just display the input values
        this.displayDetails = true;
        // Assume you have retrieved accountId and contactId from Salesforce after record creation
        this.accountId = 'Account Id from Salesforce';
        this.contactId = 'Contact Id from Salesforce';
    }
}