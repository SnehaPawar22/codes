import { LightningElement } from 'lwc';

export default class LifeCycleChildExample extends LightningElement {
    constructor(){
        super() //when we call a constructor method , we always need to call super method, its in the initilazition 
        //phase
        console.log("Child constructor called")
    }

    connectedCallback(){
        console.log("Child connectedCallback called")
    }

    renderedCallback(){
        console.log("Child renderedCallback called")
    }
}