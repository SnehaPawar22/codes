import { LightningElement, track} from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';

export default class AccountRecord extends LightningElement {
    accountId;
    name = '';
    @track selectedCountry;
    @track selectedCity;
    @track isCityDisabled = true;

    countryOptions = [
        {
            label:'USA', 
            value: 'USA'
        },
        {
            label:'UK', 
            value: 'UK'
        },
        {
            label:'India',
            value : 'India'

        }
    ];

    cityOptions = [];

    handleCountryChange(event){
        this.selectedCountry = event.detail.value;
        this.updateCityOptions();
    }

    updateCityOptions(){
        if(this.selectedCountry === 'USA'){
            this.cityOptions = [
                {
                    label: 'New York',
                    Value: 'New York'
                },
                {
                    label:'Davidson',
                    value: 'Davidson'
                }
            ];
        }
        else if(this.selectedCountry === 'UK')
        {
            this.cityOptions = [
                {
                    label: 'London',
                    Value: 'London'
                },
                {
                    label:'LiverPool',
                    value: 'LiverPool'
                }
            ];
        }

        else if(this.selectedCountry === 'India')
        {
            this.cityOptions = [
                {
                    label: 'Mumbai',
                    Value: 'Mumbai'
                },
                {
                    label:'Banglore',
                    value: 'Banglore'
                }
            ];
        }

        this.isCityDisabled = false;
        this.selectedCity = null;

    
    }

    handleCityChange(event){
        this.selectedCity = event.detail.value;
        const selectedCityLabel = this.cityOptions.find(option => option.value === this.selectedCity).label;
        this.selectedCityLabel = selectedCityLabel;
    }

    handleNameChange(event){
        this.name = event.target.value
        if(this.name.includes('$') || this.name.includes('%')){
            event.target.setCustomValidity("Account Name cannot contains '$' or '%' ");
        }else{
            event.target.setCustomValidity("");
        }
        event.target.reportValidity();
    }

    handleCreateAccount(){
        const fields = {};
        fields[NAME_FIELD.fieldApiName] = this.name;
        const recordInput = {apiName:ACCOUNT_OBJECT.objectApiName ,fields };
        createRecord(recordInput)
        .then(account =>{
            console.log("account:" +JSON.stringify(account))
            this.accountId = account.id
        })

        .catch(error =>{
            console.error("error:" +JSON.stringify(error))
        })

    }
}