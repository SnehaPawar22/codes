import { api, LightningElement } from 'lwc';

export default class AppendHtml extends LightningElement {
    _result

    @api
    get result(){
        return this._result
    }

    set result(data){
        this._result = data
    }
}